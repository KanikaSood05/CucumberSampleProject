package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {
	
	WebDriver driver;
	
	public HomePage(WebDriver cDriver) {
		driver = cDriver;
		PageFactory.initElements(cDriver, this);
	}
	
	@FindBy(linkText = "Laptops")
	WebElement linkLaptops;
	
	@FindBy(linkText = "Cart")
	WebElement linkCart;
	


	
	public void clickLaptops() {
		linkLaptops.click();
	}
	
	public void clickCart() {
		linkCart.click();
	}
	

}


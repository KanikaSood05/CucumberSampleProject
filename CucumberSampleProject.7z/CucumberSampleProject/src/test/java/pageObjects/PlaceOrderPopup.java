package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PlaceOrderPopup {
	
	WebDriver driver;
	
	public PlaceOrderPopup(WebDriver cDriver) {
		driver = cDriver;
		PageFactory.initElements(cDriver, this);
	}
	
	@FindBy(id = "name")
	WebElement txtName;
	
	@FindBy(id = "country")
	WebElement txtCountry;
	
	@FindBy(id = "city")
	WebElement txtCity;
	
	@FindBy(id = "card")
	WebElement txtCard;
	
	@FindBy(id = "month")
	WebElement txtMonth;
	
	@FindBy(id = "year")
	WebElement txtYear;
	
	@FindBy(xpath = "//button[text()='Purchase']")
	WebElement btnPurchase;
	
	
	
	@FindBy (xpath = "//h2[contains(text(),'Thank you')]")
	WebElement orderConfirmation;
	
	
	@FindBy(xpath = "//p[@class='lead text-muted ']")
	WebElement orderConfirmationDetails;
	
	@FindBy(xpath = "//button[text()='OK']")
	WebElement btnOK;

	
	public void clickPurchase() {
		btnPurchase.click();
	}
	
	public void setName(String uname) {
		txtName.clear();
		txtName.sendKeys(uname);
	}
	
	public void setCountry(String country) {
		txtCountry.clear();
		txtCountry.sendKeys(country);
	}
	
	public void setCity(String city) {
		txtCity.clear();
		txtCity.sendKeys(city);
	}
	
	public void setCard(String card) {
		txtCard.clear();
		txtCard.sendKeys(card);
	}
	
	public void setMonth(String month) {
		txtMonth.clear();
		txtMonth.sendKeys(month);
	}
	
	public void setYear(String year) {
		txtYear.clear();
		txtYear.sendKeys(year);
	}
		
	public String getOrderConfirmation() {
		String text = orderConfirmation.getText();
		return text;
	}
	
	//to be completed
	public String getorderConfirmationDetails() {
		//String[] returnArr = new String[2];
		String text = orderConfirmationDetails.getText();
//		String[] splitText=text.split("Amount :");
//		String id=splitText[0].trim();
//		String amount=splitText[1].split("Card")[0].trim();
//		returnArr[0]=id;
//		returnArr[1]=amount;
		return text;
	}
	
	public void clickOK() {
		btnOK.click();
	}
}

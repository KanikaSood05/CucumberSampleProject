package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CartPage {
	
	WebDriver driver;
	
	public CartPage(WebDriver cDriver) {
		driver = cDriver;
		PageFactory.initElements(cDriver, this);
	}
	
	@FindBy(xpath = "//td[contains(text(),'Dell i7 8gb')]/following-sibling::td/a[contains(text(),'Delete')]")
	WebElement linkDelete;
	
	@FindBy(xpath = "//button[text()='Place Order']")
	WebElement btnPlaceOrder;
	

	
	public void clickPlaceOrder() {
		btnPlaceOrder.click();
	}
	
	public void clickDelete() {
		linkDelete.click();
	}
	

}


package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LaptopDetailPage {
	
	WebDriver driver;
	
	public LaptopDetailPage(WebDriver cDriver) {
		driver = cDriver;
		PageFactory.initElements(cDriver, this);
	}
	
	@FindBy(linkText = "Add to cart")
	WebElement btnAddToCart;
	
	@FindBy(xpath = "//a[@href='index.html' and @class='nav-link']")
	WebElement btnHome;
	

	
	public void clickAddToCart() {
		btnAddToCart.click();
	}
	
	public void clickHome() {
		btnHome.click();
	}
	

}


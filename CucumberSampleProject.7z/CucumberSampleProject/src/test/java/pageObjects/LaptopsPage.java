package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LaptopsPage {
	
	WebDriver driver;
	
	public LaptopsPage(WebDriver cDriver) {
		driver = cDriver;
		PageFactory.initElements(cDriver, this);
	}
	
	@FindBy(linkText = "Sony vaio i5")
	WebElement SonyLaptop;
	
	@FindBy(linkText = "Dell i7 8gb")
	WebElement DellLaptop;
	

	
	public void clickSonyLaptop() {
		SonyLaptop.click();
	}
	
	public void clickDellLaptop() {
		DellLaptop.click();
	}
	
}


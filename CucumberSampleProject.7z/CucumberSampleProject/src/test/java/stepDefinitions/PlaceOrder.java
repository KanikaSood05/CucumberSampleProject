package stepDefinitions;


import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.sun.javafx.print.Units;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import junit.framework.Assert;
import pageObjects.CartPage;
import pageObjects.HomePage;
import pageObjects.LaptopDetailPage;
import pageObjects.LaptopsPage;
import pageObjects.PlaceOrderPopup;

public class PlaceOrder {
	
	WebDriver driver;
	HomePage hp;
	LaptopsPage lp;
	LaptopDetailPage ld;
	CartPage cp;
	PlaceOrderPopup pop;
	
	String MainWindow = "";
	
	@Given("User Launch the chrome browser")
	public void User_Launch_the_chrome_browser() {
		System.setProperty("webdriver.chrome.driver", "D://Softwares//chromedriver_win32//chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(20000, TimeUnit.MILLISECONDS);
		driver.manage().timeouts().implicitlyWait(20000, TimeUnit.MILLISECONDS);
		hp = new HomePage(driver);
		lp = new LaptopsPage(driver);
		ld = new LaptopDetailPage(driver);
		cp = new CartPage(driver);
		pop = new PlaceOrderPopup(driver);
	}

	@When("user opens URL {string}")
	public void user_opens_URL(String url) {
	   driver.get(url);
	}
	
	@Then("Page title should be {string}")
	public void Page_title_should_be(String title) {
		Assert.assertEquals(title, driver.getTitle());
	}
	
	
	@Then("user clicks on Laptops category")
	public void user_clicks_on_Laptops_category() {
	    hp.clickLaptops();
	}

	
	@Then("clicks on Sony link")
	public void clicks_on_Sony_link() {
	       		lp.clickSonyLaptop();
	}	    
	 

	@Then("clicks on cart button")
	public void clicks_on_cart_button() throws InterruptedException {
	    ld.clickAddToCart();
	    Thread.sleep(5000);
	}
	
	@Then("Popup saying {string} is displayed")
	public void popup_saying_is_displayed(String alertMsg) {
	  String  msg = driver.switchTo().alert().getText();
	  Assert.assertEquals(alertMsg, msg);
	}
	
	@Then("user clicks on OK button of the popup")
	public void user_clicks_on_OK_button_of_the_popup() throws InterruptedException {
		driver.switchTo().alert().accept();
		ld.clickHome();
		Thread.sleep(5000);
		hp.clickLaptops();		
	}	
	
	
	@Then("clicks on Dell link")
	public void clicks_on_Dell_link() throws InterruptedException {
		Thread.sleep(5000);
	    lp.clickDellLaptop();
	}

	
	@Then("user clicks on {string} from the menu bar")
	public void user_clicks_on_from_the_menu_bar(String string) {
		hp.clickCart();
	}
	
	
	@Then("user clicks on {string} link against product Dell")
	public void user_clicks_on_link_against_product_Dell(String string) throws InterruptedException {
		cp.clickDelete();
		Thread.sleep(5000);	
	}
	
	
	@Then("user clicks on Place Order button")
	public void user_clicks_on_button() throws InterruptedException {
		MainWindow=driver.getWindowHandle();
		cp.clickPlaceOrder();
		Thread.sleep(5000);	   
	}
	
	@Then("Place Order popup with various fields should be displayed")
	public void place_Order_popup_with_various_fields_should_be_displayed() {
		Set<String> s1=driver.getWindowHandles();		
        Iterator<String> i1=s1.iterator();       		
        while(i1.hasNext())			
        {		
            String ChildWindow=i1.next();		
            		
            if(!MainWindow.equalsIgnoreCase(ChildWindow)) {
            	driver.switchTo().window(ChildWindow);
            }
        }
	}
	
	
	@Then("user fill all the details in the popup")
	public void user_fill_all_the_details_in_the_popup() {
		pop.setName("testUser");
		pop.setCountry("India");
		pop.setCity("Delhi");
		pop.setCard("12345678");
		pop.setMonth("March");
		pop.setYear("2020");	
	}
	
	@Then("user clicks on {string} button on the popup")
	public void user_clicks_on_button_on_the_popup(String string) {
	    pop.clickPurchase();
	}
	
	
	@Then("purchase confirmation is displayed")
	public void purchase_confirmation_is_displayed() {
	   String text = pop.getOrderConfirmation();
	   Assert.assertEquals("Thank you for your purchase!",text );
	}
	
	
	@Then("user notes the id and Amount")
	public void user_notes_the_id_and_Amount() {
		String text = pop.getorderConfirmationDetails();
		System.out.println(text);
		
		String id = text.substring(4, 10);
		String amount = text.substring(20,27);
		System.out.println(id);
		System.out.println(amount);
		Assert.assertEquals("790 USD", amount);
	}


	@Then("clicks on the {string} button")
	public void clicks_on_the_button(String string) {
		pop.clickOK();
	}
	

	@Then("validate Home page is opened")
	public void validate_Home_page_is_opened() {
		Assert.assertEquals("STORE", driver.getTitle());
	}
	
	
	@Then("closes the browser")
	public void closes_the_browser() {
		driver.close();
	}
	
}

$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("file:Features/PlaceOrder.feature");
formatter.feature({
  "name": "Place an order",
  "description": "",
  "keyword": "Feature"
});
formatter.scenario({
  "name": "Successfully placed an order.",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@sanity"
    }
  ]
});
formatter.step({
  "name": "User Launch the chrome browser",
  "keyword": "Given "
});
formatter.match({
  "location": "PlaceOrder.User_Launch_the_chrome_browser()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user opens URL \"https://www.demoblaze.com/index.html\"",
  "keyword": "When "
});
formatter.match({
  "location": "PlaceOrder.user_opens_URL(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Page title should be \"STORE\"",
  "keyword": "Then "
});
formatter.match({
  "location": "PlaceOrder.Page_title_should_be(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user clicks on Laptops category",
  "keyword": "Then "
});
formatter.match({
  "location": "PlaceOrder.user_clicks_on_Laptops_category()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "clicks on Sony link",
  "keyword": "Then "
});
formatter.match({
  "location": "PlaceOrder.clicks_on_Sony_link()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "clicks on cart button",
  "keyword": "And "
});
formatter.match({
  "location": "PlaceOrder.clicks_on_cart_button()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Popup saying \"Product added\" is displayed",
  "keyword": "Then "
});
formatter.match({
  "location": "PlaceOrder.popup_saying_is_displayed(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user clicks on OK button of the popup",
  "keyword": "Then "
});
formatter.match({
  "location": "PlaceOrder.user_clicks_on_OK_button_of_the_popup()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user clicks on Laptops category",
  "keyword": "Then "
});
formatter.match({
  "location": "PlaceOrder.user_clicks_on_Laptops_category()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "clicks on Dell link",
  "keyword": "Then "
});
formatter.match({
  "location": "PlaceOrder.clicks_on_Dell_link()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "clicks on cart button",
  "keyword": "And "
});
formatter.match({
  "location": "PlaceOrder.clicks_on_cart_button()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Popup saying \"Product added\" is displayed",
  "keyword": "Then "
});
formatter.match({
  "location": "PlaceOrder.popup_saying_is_displayed(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user clicks on OK button of the popup",
  "keyword": "Then "
});
formatter.match({
  "location": "PlaceOrder.user_clicks_on_OK_button_of_the_popup()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user clicks on \"Cart\" from the menu bar",
  "keyword": "And "
});
formatter.match({
  "location": "PlaceOrder.user_clicks_on_from_the_menu_bar(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user clicks on \"Delete\" link against product Dell",
  "keyword": "Then "
});
formatter.match({
  "location": "PlaceOrder.user_clicks_on_link_against_product_Dell(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user clicks on Place Order button",
  "keyword": "And "
});
formatter.match({
  "location": "PlaceOrder.user_clicks_on_button()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Place Order popup with various fields should be displayed",
  "keyword": "Then "
});
formatter.match({
  "location": "PlaceOrder.place_Order_popup_with_various_fields_should_be_displayed()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user fill all the details in the popup",
  "keyword": "And "
});
formatter.match({
  "location": "PlaceOrder.user_fill_all_the_details_in_the_popup()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user clicks on \"Purchase\" button on the popup",
  "keyword": "And "
});
formatter.match({
  "location": "PlaceOrder.user_clicks_on_button_on_the_popup(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "purchase confirmation is displayed",
  "keyword": "And "
});
formatter.match({
  "location": "PlaceOrder.purchase_confirmation_is_displayed()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user notes the id and Amount",
  "keyword": "And "
});
formatter.match({
  "location": "PlaceOrder.user_notes_the_id_and_Amount()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "clicks on the \"OK\" button",
  "keyword": "And "
});
formatter.match({
  "location": "PlaceOrder.clicks_on_the_button(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "validate Home page is opened",
  "keyword": "And "
});
formatter.match({
  "location": "PlaceOrder.validate_Home_page_is_opened()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "closes the browser",
  "keyword": "And "
});
formatter.match({
  "location": "PlaceOrder.closes_the_browser()"
});
formatter.result({
  "status": "passed"
});
});